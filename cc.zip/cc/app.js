let img = document.querySelectorAll(".grand>.parent>.cash>img");
// let image = document.querySelectorAll(".grand_none>.parent>.cash>img");
let img11 = document.querySelector(".grand_none");
let class0 = document.querySelectorAll(".grand>.parent>.cash");
let class1 = document.querySelectorAll(".grand_none>.parent>.cash");
let classP = document.querySelectorAll(".grand_none>.parent>.cash>p");
let div = document.querySelector(".container>img");
let container = document.querySelector(".container");
let p = document.createElement("p");
document.body.append(p);
container.append(p);
document.addEventListener("DOMContentLoaded", function () {
    img.forEach(el => el.addEventListener('click', e => {
        e.preventDefault();
        div.setAttribute("src", el.src);
        p.style = "display:block";
        p.innerHTML = el.nextElementSibling.textContent;
    }))

    class0.forEach(element1 => {
        element1.addEventListener('click', e => {
            e.preventDefault()
            img11.style = 'display:flex';
            class1.forEach(element2 => {
                class0.forEach(e2 => {
                    e2.style = "display:none";
                    document.getElementById("bouton").style = "display:block";
                })
                class1.forEach(e1 => {
                    if (e1.className != element1.className) {
                        e1.style = "display:none"
                    }
                    else {
                        e1.style = 'display:flex; flex-wrap: wrap; flex-basis: 100%; gap: 1em';
                        // image.forEach(e4 => {
                        //     e4.style = 'flex-basis: 20%';
                        // })
                    }
                    classP.forEach(e3 => {
                        e3.style = "display:block; flex-basis: 100%"
                    })
                })
            })
        })
    });
})

let search = document.querySelector('#search');
let closes = document.querySelector('#close');
document.addEventListener("DOMContentLoaded", function() {
    search.addEventListener("click", (e) => {
        e.preventDefault();
        search.style = "width:100%";
        closes.style = "display:block";
    })
    closes.addEventListener("click", (e) => {
        e.preventDefault();
        search.style = "width:20%";
        closes.style = "display:none";
    })
})