<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .relative {
            position: relative;
            width: 800px;
            height: 800px;
        }
        .absolute {
            position: absolute;
            display: none;
            top: 0;
            z-index: 1;
            width: 800px;
            height: 800px;
        }
        .absolute>img {
            width: 800px;
            height: 800px;
        }
        .solute {
            position: absolute;
            z-index: 1;
            top: 50%;
            padding: 1em;
            background-color: #f50;
        }
        .solute>span {
            color: white;
            font-size: 20px;
            font-weight: bold;
        }
        .left {
            left: 0;
        }
        .right {
            right:0;
        }
    </style>
</head>
<body>
    <div class="relative">
        <div class="absolute">
            <img src="bleach.jpg" alt="bleach">
        </div>
        <div class="absolute">
            <img src="boruto - Copie.jpg" alt="boruto">
        </div>
        <div class="absolute">
            <img src="la_rosée_de_la_nuit - Copie.jpg" alt="la rosée de la nuit">
        </div>
        <div class="absolute">
            <img src="le_solitaire - Copie.jpg" alt="le solitaire">
        </div>
        <div class="solute left">
            <span><</span>
        </div>
        <div class="solute right">
            <span>></span>
        </div>
    </div>

    <script>
        let show = 1;
        showSlides(show);
        function solute_right(n) {
            showSlides(show += n);
        }
        function solute_left(n) {
            showSlides(show = n);
        }
        function showSlides(n) {
            let i;
            let absolute = document.querySelectorAll('.absolute');
            if(n>absolute.length) {
                show = 1;
            }
            if(n<1) {
                show = absolute.length;
            }
            for(i = 0; i<show; i++) {
                absolute[i].style.display = "none";            
            }
            absolute[show-1].style.display = "block"; 
        }
        
    </script>
</body>
</html>