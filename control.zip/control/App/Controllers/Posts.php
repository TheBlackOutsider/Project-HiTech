<?php

class Posts {
    public function indexPosts() {
        echo "Hello !!! Vous sur l'index de Posts.";
    }
}

?>